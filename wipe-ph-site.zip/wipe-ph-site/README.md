# WIPE PH — Landing Page

A single-page static site for WIPE PH (item cleaning & restoration) built to drive bookings through the embedded calendar.

## Structure
```
.
├── index.html      # the whole site (HTML/CSS/JS in one file)
├── wipe-logo.png   # brand logo, referenced by index.html
├── vercel.json     # Vercel config (clean URLs)
└── .gitignore
```

No build step, no dependencies — it's a static HTML file, so Vercel deploys it as-is.

## Deploy: GitHub → Vercel

**1. Push this folder to GitHub**
```bash
git init
git add .
git commit -m "Initial commit: WIPE PH landing page"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
(Create the empty repo on GitHub first, then run the commands above from inside this folder.)

**2. Import into Vercel**
1. Go to [vercel.com/new](https://vercel.com/new)
2. Choose **Import Git Repository** and select the repo you just pushed
3. Framework Preset: **Other** (it's a static site — no build command, no output directory needed)
4. Click **Deploy**

Vercel will detect `index.html` at the root and serve it directly. Every future `git push` to `main` auto-redeploys.

## Local preview
Just open `index.html` in a browser, or run a quick local server:
```bash
python3 -m http.server 8000
```
Then visit `http://localhost:8000`.

## Editing
- Booking calendar: the GHL iframe lives in the `#booking` section of `index.html`.
- Brand colors live at the top of the `<style>` block as CSS variables (`--yellow`, `--ink`, etc.).
- Logo: replace `wipe-logo.png` (keep the same filename, or update the `src` in `index.html`).
